// extension/render.js
// Pure HTML-string builders for the answer overlay -- no DOM access, no
// chrome.* APIs, so these are unit-testable (extension/render.test.js) the
// same way lib.js is. Mirrors demo/index.html's own renderAnswer/
// renderUnknown/renderLoading structure and copy, so the extension and the
// web demo speak with the same voice ("grounded answer" / "No one wrote this
// down." / citation chips grouped by source type).

function escapeHtml(s) {
  return (s || "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

function sourceOf(ref) {
  const p = (ref || "").split(":")[0];
  return ["pr", "issue", "code", "doc", "config", "commit", "index"].includes(p) ? p : "ref";
}

// `index:` evidence is Icarus reporting what it READ -- file counts, languages,
// what got indexed -- measured from the repository rather than written by a
// person. It has no source page, so it never links. Shown in words instead of
// as a raw ref: `index:overview` sitting in a row beside `pr:1482` reads as a
// document somebody wrote, which is exactly the claim it must not make.
const INDEX_LABEL = "Icarus's own index";

function citationLabel(ref) {
  return sourceOf(ref) === "index" ? INDEX_LABEL : ref;
}

// The three small states share one wrapper: a label line plus a body. Only
// the label's class/text and the body vary.
function block(labelClass, label, bodyHtml) {
  return `<div class="icarus-block"><p class="icarus-label ${labelClass}">${label}</p>${bodyHtml}</div>`;
}

function renderLoadingHtml() {
  return block("icarus-muted", "thinking…", "");
}

function renderSignedOutHtml() {
  return block("", "not signed in",
    "<p>Sign in with GitHub from the Icarus toolbar icon to ask questions here.</p>");
}

function renderErrorHtml(message) {
  return block("icarus-danger", "something went wrong", `<p>${escapeHtml(message)}</p>`);
}

function renderAnswerHtml(payload, opts) {
  const chips = (payload.citations || [])
    .map((c) => {
      const s = sourceOf(c.ref);
      const inner = `<span class="icarus-src icarus-src-${s}">${escapeHtml(s)}</span>`
        + escapeHtml(citationLabel(c.ref));
      // An index citation never links, even if a URL were somehow supplied:
      // there is no page that "what Icarus read" lives on, and a link would
      // imply a human-authored source behind it.
      return c.url && s !== "index"
        ? `<a class="icarus-chip" href="${escapeHtml(c.url)}" target="_blank" rel="noopener">${inner}</a>`
        : `<span class="icarus-chip">${inner}</span>`;
    })
    .join("");
  return (
    '<div class="icarus-block">' +
    '<p class="icarus-label icarus-grounded">grounded answer</p>' +
    `<div class="icarus-answer-prose">${escapeHtml(payload.answer)}</div>` +
    '<div class="icarus-evidence">' +
    '<p class="icarus-label icarus-muted">evidence — one glance away</p>' +
    `<div class="icarus-cites">${chips}</div>` +
    "</div>" +
    `<div class="icarus-repo-label">${repoLabel(opts)}</div>` +
    "</div>"
  );
}

// The connected repo's real kind, from the brain's /status -- this used to be a
// hardcoded "public repository alpha", which stopped being true when private
// repos were re-enabled (2026-07-16). Defaults to public: never over-claim that
// a repo is private code.
function repoLabel(opts) {
  return opts && opts.isPrivate ? "private repository alpha" : "public repository alpha";
}

function renderUnknownHtml(payload) {
  const named = payload.anchored || [];
  const rest = (payload.searched || []).filter((r) => !named.includes(r));
  // Say what the QUESTION named, separately from what search suggested: a bare
  // count made a refusal that looked up the named ref first indistinguishable
  // from one that ignored the question (reported live 2026-07-28).
  const namedLine = named.length
    ? `<div class="icarus-searched">you named: ${escapeHtml(named.join(" · "))}</div>`
    : "";
  const lead = named.length ? "then searched" : "searched";
  // An abstention while the index is still building is "I haven't finished
  // reading", not "no one wrote this down" -- only the latter is a claim about
  // the repository, and conflating them is what this product must never do.
  let head = payload.indexing
    ? '<p class="icarus-label">still indexing</p>' +
      "<h2>I haven’t finished reading this repo.</h2>" +
      "<p>Search is keyword-only until indexing finishes — ask again shortly.</p>"
    : null;
  if (!head && payload.reason === "entity_absent") {
    head = '<p class="icarus-label">not found</p>' +
      "<h2>That entity wasn’t found.</h2>" +
      "<p>Icarus could not find the named pull request, issue, or commit.</p>";
  } else if (!head && ["no_recorded_reason", "writer_found_no_reason"].includes(payload.reason)) {
    head = '<p class="icarus-label">honest answer</p>' +
      "<h2>No one wrote this down.</h2>" +
      "<p>The evidence doesn’t record a reason, so Icarus won’t invent one.</p>";
  } else if (!head) {
    head = '<p class="icarus-label">honest unknown</p>' +
      "<h2>Not enough evidence.</h2>" +
      "<p>Icarus could not produce a grounded answer from what it found.</p>";
  }
  return (
    '<div class="icarus-unknown">' +
    head +
    namedLine +
    `<div class="icarus-searched">${lead} ${rest.length} source${rest.length === 1 ? "" : "s"}</div>` +
    "</div>"
  );
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    escapeHtml,
    sourceOf,
    citationLabel,
    renderLoadingHtml,
    renderSignedOutHtml,
    renderErrorHtml,
    renderAnswerHtml,
    renderUnknownHtml,
  };
}
